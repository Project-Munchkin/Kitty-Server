package com.munchkin.munchkin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MunchkinApplication {

	public static void main(String[] args) {
		SpringApplication.run(MunchkinApplication.class, args);
	}
}
